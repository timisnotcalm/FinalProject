insert into users (fullname, username, password, email, phone_number, course_id) values
('Admin admin', 'admin', '123', 'admin@gmail.com', '8498382920',  null),
('Nur Sul', 'bob', '123', 'bro@gmail.com', '83739792',  null)
